<?php 

	$smarty = new SmartyBC();
	$smarty->setTemplateDir('App/View');
	$smarty->display('desculpa.html');
 ?>