<?php 

	$smarty = new SmartyBC();
	$smarty->setTemplateDir('App/View');
	$smarty->display('404.html');
 ?>