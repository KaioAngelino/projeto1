<?php
/* Smarty version 3.1.33, created on 2019-09-03 17:33:55
  from 'C:\wamp\www\projeto1\App\View\desculpa.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d6ea4036a6c95_08539020',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8fd3dd8d50453274f194abc8881021ed275a777' => 
    array (
      0 => 'C:\\wamp\\www\\projeto1\\App\\View\\desculpa.html',
      1 => 1567532033,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d6ea4036a6c95_08539020 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Desculpa :( !</h1>
<h3>Parece que tivemos um problema no seu cadastro, verifica seus dados!.</h3>
<a href="home">Voltar para página Inicial</a><?php }
}
