<?php
/* Smarty version 3.1.33, created on 2019-09-05 17:27:57
  from 'C:\wamp\www\projeto1\App\View\agradecimento.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d71459d1c9007_08769125',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fef456d674c7c8a0e973eb695315b6c6a033d479' => 
    array (
      0 => 'C:\\wamp\\www\\projeto1\\App\\View\\agradecimento.html',
      1 => 1567703513,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d71459d1c9007_08769125 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>OBRIGADO</h1>
<h3> Verifica o teu email!</h3>
<a href="home">Voltar</a>
<?php exit;
}
}
