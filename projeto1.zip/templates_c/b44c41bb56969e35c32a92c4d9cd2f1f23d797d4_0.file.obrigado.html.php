<?php
/* Smarty version 3.1.33, created on 2019-09-05 18:05:04
  from 'C:\wamp\www\projeto1\App\View\obrigado.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d714e5041b135_09097198',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b44c41bb56969e35c32a92c4d9cd2f1f23d797d4' => 
    array (
      0 => 'C:\\wamp\\www\\projeto1\\App\\View\\obrigado.html',
      1 => 1567706700,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d714e5041b135_09097198 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Valeu!</h1>
<h3>Aqui em baixo temos o nosso conteúdo em PDF</h3>

<div class="embed-responsive embed-responsive-4by3 mx-auto" style="width: 40%">
    <iframe class="embed-responsive-item" src="https://youtu.be/Ut2IA4bA-g8" allowfullscreen></iframe>
</div>

<button class="btn btn-blank">
    <a href="App/downloads/nota_agradecimento.pdf" download="nota_agradecimento.pdf">Baixar conteúdo</a></button>
<button type="button" class="btn btn-light">Cadastro Completo</button><?php }
}
