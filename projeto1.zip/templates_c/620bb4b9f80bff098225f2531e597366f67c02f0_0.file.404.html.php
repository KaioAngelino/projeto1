<?php
/* Smarty version 3.1.33, created on 2019-08-27 18:49:01
  from 'C:\wamp\www\projeto1\App\View\404.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d657b1d993513_77705570',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '620bb4b9f80bff098225f2531e597366f67c02f0' => 
    array (
      0 => 'C:\\wamp\\www\\projeto1\\App\\View\\404.html',
      1 => 1566327274,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d657b1d993513_77705570 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>404 Página não encontrada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    @media screen and (max-width:500px) {
      body { font-size: .6em; } 
    }
  </style>
</head>

<body style="text-align: center;">

  <h1 style="font-family: Georgia, serif; color: #4a4a4a; margin-top: 4em; line-height: 1.5;">
    Verifique o endereço<br>colocado acima.
  </h1>
  
  <h2 style="  font-family: Verdana, sans-serif; color: #7d7d7d; font-weight: 300;">
    404 Página não encontrada.
  </h2>
  
</body>

</html><?php }
}
